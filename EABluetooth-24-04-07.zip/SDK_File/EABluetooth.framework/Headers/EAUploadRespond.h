//
//  EAUploadRespond.h
//  EABluetooth
//
//  Created by Aye on 2021/3/22.
//

#import <EABluetooth/EABaseBigDataModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface EAUploadRespond : EABaseBigDataModel

/** 数据需求 */
@property(nonatomic, assign) NSInteger requestId;




@end





NS_ASSUME_NONNULL_END
