//
//  EADBRestingHrModel.h
//  EABluetooth
//
//  Created by Aye on 2023/2/7.
//

#import "EADBBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface EADBRestingHrModel : EADBBaseModel

/// 心率值
@property NSInteger hr;


@end

NS_ASSUME_NONNULL_END
